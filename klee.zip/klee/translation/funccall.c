//#include <stdio.h>
int max(int a, int b)
{
    if (a > b)
       return a;
    return b;
}

int main(void){
    int i;
	if (i>2)
    max(5,6);
}
