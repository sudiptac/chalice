int a[100];   

int main(void){
int i;
   for(i=1;i<=100;i++)
        a[i]+=5;
    return 0;
}
